/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cifpcm.vuelos.Dao;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Pablo1
 */
@XmlRootElement
public class ReservaPOJO implements Serializable{
    
    private Integer nReservas;
    private String nombre;
    private String apellidos;
    private String telefono;
    private String tarjeta;
    private Integer idVuelo;
    private Integer importe;

    public ReservaPOJO() {
    }

    public ReservaPOJO(Integer nReservas, String nombre, String apellidos, String telefono, String tarjeta, Integer idVuelo, Integer importe) {
        this.nReservas = nReservas;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.tarjeta = tarjeta;
        this.idVuelo = idVuelo;
        this.importe = importe;
    }

    public Integer getnReservas() {
        return nReservas;
    }

    public void setnReservas(Integer nReservas) {
        this.nReservas = nReservas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(String tarjeta) {
        this.tarjeta = tarjeta;
    }

    public Integer getIdVuelo() {
        return idVuelo;
    }

    public void setIdVuelo(Integer idVuelo) {
        this.idVuelo = idVuelo;
    }

    public Integer getImporte() {
        return importe;
    }

    public void setImporte(Integer importe) {
        this.importe = importe;
    }
    
    
}
