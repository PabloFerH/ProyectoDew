$(document).ready(function(){
  // Add smooth scrolling to all links
  $("a").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 1000, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
    
 $("#reservas").on("click", function(){
       $(this).menuReserva();
 });

 $("#consultar").on("click", function(){
       $().consultarDatos();
 });
 
$("#precio").val(850);
 $("#precio").keydown(function (event) {
        if (isNaN(event.key) && (event.key != "Backspace")) {
            event.preventDefault();
        }
    });
	
  $().loopBotonInicio();
  $().loopReserva();
  $().fechas();
  $().idiomaSlide();
  $().cambiarIdioma();
 // $().crearFormulario();

});

$.fn.cambiarIdioma = function(){
    var icon = $("#iconoIdioma");
    $("ul").children("li").children("a").on("click", function(){
        $("#menu1").text(event.currentTarget.text);
        $("#menu1").append(icon);
        $("#opcionesIdioma").slideToggle(); 
    })
}


$.fn.idiomaSlide = function(){
    $("#menu1").on("click",function(){
       $("#opcionesIdioma").slideToggle(); 
    });
}

$.fn.fechas = function(){
  $(".fechas").timepicker({ 'timeFormat': 'H:i' });
  $(".fechas").keydown(function(event) { 
    return false;
});
}

$.fn.loopBotonInicio = function(){
    function loop(){
     $('#flecha')
     .animate({color:'rgba(255,255,255,0.1)'},1000)
     .animate({color:'rgba(255,255,255,1)'},1000,loop);
    }
    loop();
}

$.fn.loopReserva = function(){
  function loop(){
  if($(".aside").hasClass("col-md-1")){
   $('#reservas')
   .animate({color:'rgba(255,255,255,0.4)'},1000)
   .animate({color:'rgba(255,255,255,1)'},1000,loop);
  }else if($(".aside").hasClass("col-md-3")){
    $('#reservas')
   .animate({color:'rgba(255,255,255,1)'},1000,loop);
  }
  }
  loop();
}

$.fn.menuReserva = function () {
	if($(".contenedor").hasClass("col-md-11")){
        $(".contenedor").toggleClass("col-md-9",250).toggleClass("col-md-11",250);       
        $(".aside").toggleClass("col-md-3",250).toggleClass("col-md-1",250);
        if(!($(document).width() <= 991)){
            $("#reservas").css({
            transition: "transform 0.8s",
            transform: "rotate(0deg)"});
        }else{
            $("#inicio").css({
                transition: "height 0.8s",
                height: "650px"});
        }
     $("form").css({
            transition: "transform 0.8s",
            transform:"translate(0px)"}); 
    }else{	
        $(".contenedor").toggleClass("col-md-11",250).toggleClass("col-md-9",250);
        
        $(".aside").toggleClass("col-md-1",250).toggleClass("col-md-3",250);
        if(!($(document).width() <= 991)){
        $("#reservas").css({
            transition: "transform 0.8s",
            transform: "rotate(-90deg) translate(-200px)"});
        }else{
            $("#inicio").css({
                transition: "height 0.8s",
                height: "100px"});
        }
        $("form").css({
            transition: "transform 0.8s",
            transform:"translate(-850px)"});
    }
};


$.fn.desactivarBoton = function(){
    $("#reservas").off("click", function(){
       $(this).menuReserva();
 });
    $().activarBoton();
}

$.fn.activarBoton = function(){
    $("#reservas").delay(800).on("click", function(){
       $(this).menuReserva();
 });
}


$.fn.consultarDatos = function(){
  //Añadir que cuando clickes en consultar se cambio el titulo a vuelos disponibles
  var valores = [];
  var campos = $(".obligatorio");
  for(var i = 0; i < campos.length; i++){
    if(!$(campos[i]).val() == ""){
      valores.push($(campos[i]).val());
    }else{
	  $().notificacion("error", "Alguno de los campos obligatorios está vacio");
      return;
    }
  }
  $(".fila2").fadeOut(300);
  //$().tablaConsulta();
  
  
  
  var vuelo = {
        horaSalida: $("#horaSalida").val(),
        horaLlegada: $("#horaLlegada").val(),
        precio: $("#precio").val().trim(),
        nombreAerolinea: $("#aerolinea").val().replace(/ /g, "").toLowerCase(),
        nombreCiudadSalida: $("#salida").val().replace(/ /g, "").toLowerCase(),
        nombreCiudadLlegada: $("#destino").val().replace(/ /g, "").toLowerCase()
    };
    var request = $.ajax({
        url: "webresources/vuelos/",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify(vuelo),
        dataType: "json",
        success: function (vuelos) {
            $().tablaConsulta(vuelos);
        }
    });

}


var datosJson;


$.fn.tablaConsulta = function(datos){
  $(".table-responsive").remove();
  //var datos = '[{"mierda": 2,"idvuelo": 1, "nombreCiudadSalida": "La Laguna", "nombreCiudadLlegada": "Madrid", "horaSalida": "09:00", "horaLlegada": "09:45", "nombreAerolinea": "Ryanair", "precio":40},{"mierda": 2,"idvuelo": 1, "nombreCiudadSalida": "La Laguna","nombreCiudadLlegada": "Madrid", "horaSalida": "09:00", "horaLlegada": "09:45", "nombreAerolinea": "Ryanair", "precio":40}]';

  var datosValido = ["idVuelo","nombreCiudadSalida","nombreCiudadLlegada","horaSalida","horaLlegada","nombreAerolinea","precio"];
  
  //var datosJson = JSON.parse(datos);
  //var datosJson = datos;
  datosJson = datos;
  var datosLength = Object.keys(datosJson[0]).length;

    var tablaResponsiva = $("<div class='table-responsive'></div>");
    $(tablaResponsiva).hide();
    var tabla = $("<table></table>");
    $(tabla).addClass("table");
    $(tabla).addClass("table-striped");
    $(tablaResponsiva).append(tabla);
    $(".contenedor").append(tablaResponsiva);
    $(tablaResponsiva).delay(300).fadeIn(300);
    
    var tbody = $("<tbody></tbody>");
    $(tabla.append(tbody));    
    for(var i = 0; i < datosJson.length; i++){
    var datosObjeto = Object.keys(datosJson[0]);
    var row = $("<tr></tr>");
    $(tbody.append(row));
    for(var y = 0; y < datosValido.length; y++){
             var column = $("<td></td>");
             $(column).text(datosJson[i][datosValido[y]]);
             $(row).append(column);     
    }
  }
    var titulosTabla = ["Id Vuelo","Ciudad Salida", "Ciudad Llegada", "Hora salida", "Hora llegada", "Compañia", "Precio(€)", "Reservar"];
    var idTabla = ["idVuelo","ciudadSalida", "ciudadLlegada", "horaSalidaVuelo", "horaLlegadaVuelo", "compania", "precioVuelo", "reservar"];
    
    var row = $("<tr></tr>");
    $(row).attr("id","titulos");
    $(tbody).before(row);
    
    for(var i = 0; i < titulosTabla.length; i++){
        var column = $("<td></td>");
        $(column).attr("id",idTabla[i]);
        $(column).text(titulosTabla[i]);
        $(row).append(column);
    }
    
$().reservarBotones();
    
}

$.fn.crearTabla = function(datos){
    $(".table-responsive").remove();
    
}

$.fn.tablaFecha = function(importe){
     //var datos = '[{"mierda": 2,"idvuelo": 1, "nombreCiudadSalida": "La Laguna", "nombreCiudadLlegada": "Madrid", "horaSalida": "09:00", "horaLlegada": "09:45", "nombreAerolinea": "Ryanair", "precio":40,"fecha":"13/10/2010","plazasLibres":1},{"mierda": 2,"idvuelo": 1, "nombreCiudadSalida": "La Laguna","nombreCiudadLlegada": "Madrid", "horaSalida": "09:00", "horaLlegada": "09:45", "nombreAerolinea": "Ryanair", "precio":40,"fecha":"13/10/2010","plazasLibres":1}]';

  var datosValido = ["idVuelo","fecha","plazasLibres"];
  
  //var datosJson = JSON.parse(datos);
  var datosLength = Object.keys(datosJson[0]).length;

    var tablaResponsiva = $("<div class='table-responsive'></div>");
    $(tablaResponsiva).hide();
    var tabla = $("<table></table>");
    $(tabla).addClass("table");
    $(tabla).addClass("table-striped");
    $(tablaResponsiva).append(tabla);
    $(".contenedor").append(tablaResponsiva);
    $(tablaResponsiva).delay(300).fadeIn(300);
    
   var tbody = $("<tbody></tbody>");
    $(tabla.append(tbody));    
    for(var i = 0; i < datosJson.length; i++){
    var datosObjeto = Object.keys(datosJson[0]);
      var row = $("<tr></tr>");
      $(tbody.append(row));
      for(var y = 0; y < datosValido.length; y++){
             var column = $("<td></td>");
             $(column).text(datosJson[i][datosValido[y]]);
             $(row).append(column);     
      }
      
  }
    
    var titulosTabla = ["Id Vuelo", "Fecha","Plazas libres", "Reservar"];
    var idTabla = ["idVuelo", "fecha","plazasLibres", "reservar"];
    
    var row = $("<tr></tr>");
    $(row).attr("id","titulos");
    $(tbody).before(row);
    
    for(var i = 0; i < titulosTabla.length; i++){
        var column = $("<td></td>");
        $(column).attr("id",idTabla[i]);
        $(column).text(titulosTabla[i]);
        $(row).append(column);
    }
    
    $().reservarBotones2(importe);
    
}

$.fn.reservarBotones2 = function(importe){
    var columnaBoton = $("<td></td>");
    var boton = $("<button type='button' class='btn btn-info'>Click!</button> ");
    $(columnaBoton).append(boton);
    $("table").find("tr").not(":first").append(columnaBoton);
    
    $(".btn-info").on("click", function(){
        var idVuelo = $(this).parents('tr').children().first().text()
        var fecha = $(this).parents('tr').children().first().next().text()
        $().crearFormulario(idVuelo, fecha, importe);
    });
}

$.fn.reservarBotones = function(){
    var columnaBoton = $("<td></td>");
    var boton = $("<button type='button' class='btn btn-info'>Click!</button> ");
    $(columnaBoton).append(boton);
    $("table").find("tr").not(":first").append(columnaBoton);
    
    $(".btn-info").on("click", function(){
        var importe = $(this).parent().prev().text()
        $(".table-responsive").remove();
        $().tablaFecha(importe);
    });
}

$.fn.crearFormulario = function(nVuelo, fecha, importe){
    var formularioBackground = $("<div id='formularioBackground'></div>");
    $("body").before(formularioBackground);
    var elemento = $("#formularioBackground").offset().left;
    $("#formularioBackground").css({left:elemento})
             .animate({"left":"0px"}, 1200);
    
    
    var botonCerrar = $("<div id='cerrar' ></div>");
    var iconoCerrar = $(" <span class='glyphicon glyphicon-remove' aria-hidden='true'></span>");
    $(botonCerrar).append(iconoCerrar);
    
    $(botonCerrar).on("click", function(){
       $().cerrarFormulario(); 
    });
    
    $("#menu1").css({
        position:"fixed"
    });
    
    $('html, body').css({
        overflowY: 'hidden',
        height: '100%'
    });
    
    $("#formularioBackground").append(botonCerrar);
    var contenedor = $("<div class='container'></div>");
    $("#formularioBackground").append(contenedor);
    
    var formulario = $("<form class='form-horizontal col-xs-12' id='formularioData'></form>");
    $(contenedor).append(formulario);
    
    var tituloFormulario = $("<h1 id='tituloForm'>Reserva del vuelo</h1>");
    $("#formularioData").append(tituloFormulario);
    
    var divTablaDatos = $("<div class='table-responsive'></div>");
    $("#formularioData").append(divTablaDatos);
    
    var tablaDatos = $("<table class='table table-striped' id='tablaForm'></table>");
    $(divTablaDatos).append(tablaDatos);
    
    var titulos = ["Nº del vuelo","Fecha","Importe"];
    var titulosId = ["nVuelo","fecha","importe"];
    var row = $("<tr></tr>");
    $(tablaDatos).append(row);
    for(var i = 0; i < titulos.length; i++){
        var column = $("<td>"+titulos[i]+"</td>");
        $(row).append(column);
    }
    
    var datosRecogidos = [nVuelo,fecha,importe];
    var row = $("<tr></tr>");
    $(tablaDatos).append(row);
    for(var i = 0; i < 3; i++){
        var column = $("<td id="+titulosId[i]+">"+datosRecogidos[i]+"</td>");
        $(row).append(column);
    }
    
    
    $().crearInputsFormulario("Nombre","usuario","usuarioTexto","text");
    $().crearInputsFormulario("Apellidos","apellidos","apellidosTexto","text");
    $().crearInputsFormulario("Telefono","telefono","telefonoTexto","text");
    $().crearInputsFormulario("Nº de billetes","billete","billeteTexto","number");
    $().crearInputsFormulario("Nº de tarjeta de crédito","tarjeta","tarjetaTexto","text");
    
    
    var divBoton = $("<div class='col-md-12 text-center' id='divBoton'></div>");
    $("#formularioData").append(divBoton); 
    
    var botonEnviar = $("<button type='button' class='btn btn-info' id='reservaButton'>Reservar</button>");
    $("#divBoton").append(botonEnviar); 
    
	$(botonEnviar).on("click", function(){
		$().comprobarDatosFormulatio();
	});
    
}


$.fn.comprobarDatosFormulatio = function(){
	      
        var reserva = {
        nReservas: $("#billete").val(),
        nombre: $("#usuario").val().replace(/ /g, "").toLowerCase(),
        apellidos: $("#apellidos").val().replace(/ /g, "").toLowerCase(),
        telefono: $("#telefono").val().replace(/ /g, ""),
        tarjeta: $("#tarjeta").val().replace(/ /g, ""),
        idVuelo: parseInt($("#nVuelo").text()),
        importe: parseInt($("#importe").text())
    };
    var request = $.ajax({
        url: "webresources/vuelos/reserva",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify(reserva),
        dataType: "json",
        success: function (reserva) {
            $().notificacion("success", "Se ha realizado la reserva del vuelo");   
        }
    });
              
}

$.fn.cerrarFormulario = function(){
    var elemento = $("#formularioBackground").offset().left;
    $("#formularioBackground").css({left:elemento})
             .animate({"left":"100%"}, 1200, function(){
        $().borrarFormulario();
    });
    
    $("#menu1").css({
        position:"absolute"
    });
    
  $('html, body').css({
    overflowY: '',
    height: '100%'
});
}

$.fn.borrarFormulario = function(){
    $("#formularioBackground").remove();
}

$.fn.crearInputsFormulario = function(texto, idInput, idLabel,tipo){
    var parte = $("<div class='group'></div>");
    $("#formularioData").append(parte);
    
    var input = $("<input type="+tipo+" class='obligado' required>")
    $(input).attr("id",idInput);
    $(parte).append(input);
    
    var label = $("<label></label>");
    $(label).text(texto);
    $(label).attr("id",idLabel);
    $(parte).append(label);
    
}

$.fn.notificacion = function (type, message) {
    if (type == 'success') {
        toastr.success(message, '<i>Éxito</i>');
    }
    else if (type == 'error') {
        toastr.error(message, 'Error');
    }
    else if (type == 'warning') {
        toastr.warning(message, 'Peligro');
    }
    else {
        toastr.info(message, 'Información');
    }
}
