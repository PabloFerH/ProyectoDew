window.addEventListener("DOMContentLoaded", function ()
{

});

/*function refreshActorList() {
    var custList = $('#actorList');
    custList.empty();
    $.ajax({
        "url": "webresources/vuelos/",
        "type": "get",
        "dataType": "json",
        "success": function (vuelos) {
            //console.log(actors);
            $.each(vuelos, function (i, vuelo) {
                var li = $('<li/>')
                        .addClass('ui-menu-item')
                        .attr('role', 'menuitem')
                        .appendTo(custList);
                var a = $('<a/>')
                        .addClass('ui-all')
                        .text(vuelo.horaLlegada + ' ' + vuelo.horaSalida + ' ' + vuelo.precio)
                        .appendTo(li);
            });
        }
    });
}*/
/*$(function () {
 refreshActorList();
 });*/

$("#Consultar").click(function (event) {
    var custList = $('#actorList');
    custList.empty();
    var vuelo = {
        horaSalida: $("#horaSalida").val(),
        horaLlegada: $("#horaLlegada").val(),
        precio: $("#precio").val(),
        nombreAerolinea: $("#aerolinea").val(),
        nombreCiudadSalida: $("#salida").val(),
        nombreCiudadLlegada: $("#destino").val()
    };
    var request = $.ajax({
        url: "webresources/vuelos/",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify(vuelo),
        dataType: "json",
        success: function (vuelos) {
            console.log(vuelos);
            $.each(vuelos, function (i, vuelo) {
                var li = $('<li/>')
                        .addClass('ui-menu-item')
                        .attr('role', 'menuitem')
                        .appendTo(custList);
                var a = $('<a/>')
                        .addClass('ui-all')
                        .text(vuelo.horaLlegada + ' ' + vuelo.horaSalida + ' ' + vuelo.precio)
                        .appendTo(li);
            });
        }
    });
});

$("#insertar").click(function (event) {
    var reserva = {
        nReservas: 3,
        nombre: "Pablo",
        apellidos: "Fernadez Herrera",
        telefono: "922223991",
        tarjeta: "457785245",
        idVuelo: 1,
        importe: 30
    };
    var request = $.ajax({
        url: "webresources/vuelos/reserva",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify(reserva),
        dataType: "json",
        success: function (reserva) {
            console.log("Compra realizada");
            
        }
    });
});