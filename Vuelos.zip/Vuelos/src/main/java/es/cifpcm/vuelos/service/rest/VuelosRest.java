/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cifpcm.vuelos.service.rest;

import es.cifpcm.vuelos.Dao.MySqlDaoFactory;
import es.cifpcm.vuelos.Dao.ReservaPOJO;
import es.cifpcm.vuelos.Dao.VueloDao;
import es.cifpcm.vuelos.Dao.VueloPOJO;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Pablo1
 */
@Path("vuelos")
public class VuelosRest {

    private final Logger log  = LoggerFactory.getLogger(VuelosRest.class);
    
    private static VueloDao vueloDao = MySqlDaoFactory.getInstance().getVueloDao();
    private static List<VueloPOJO> listaVuelos;
    
    static {
        listaVuelos= new ArrayList<>();
    }
    
    public VuelosRest() {
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<VueloPOJO> read() {
        log.debug("refresca");
        
        return vueloDao.selectAll();
    }
    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public List<VueloPOJO> select(VueloPOJO vuelo) {
        log.debug("insert. salida={}, llegada={}", vuelo.getHoraLlegada(), vuelo.getHoraSalida());

        return vueloDao.select(vuelo);
        //return vueloDao.selectAll();
        
    }
    
    @POST
    @Path("{reserva}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void insert(ReservaPOJO reserva) {
        //log.debug("insert. salida={}, llegada={}", vuelo.getHoraLlegada(), vuelo.getHoraSalida());

        vueloDao.insert(reserva);
        //return vueloDao.selectAll();
        
    }
    
    
}
