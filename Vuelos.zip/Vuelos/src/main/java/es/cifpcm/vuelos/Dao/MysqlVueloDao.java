/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cifpcm.vuelos.Dao;

import es.cifpcm.vuelos.conection.ConnectionProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Pablo1
 */
public class MysqlVueloDao implements VueloDao, ConnectionProvider {

    private ConnectionProvider connProvider = null;

    MysqlVueloDao(ConnectionProvider connProvider) {
        this.connProvider = connProvider;
    }

    @Override
    public List<VueloPOJO> select(VueloPOJO vuelo) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

        final String query = "select idVueloGenerico,nVuelo,horaSalida,horaLlegada,precio,capacidad,idAerolínea,nombreAerolinea,"
                + " codigoAerolinea,idAeropuerto,nombreAeropuerto,codigoAeropuerto,categoria,idCiudad,nombreCiudad,pais, idVuelo, fecha, plazasLibres from vista_vuelos "
                + "where nombreCiudad = ? AND precio <= ? AND horaSalida = ? AND horaLlegada = ?;";

        List<VueloPOJO> listaVuelos = new ArrayList<VueloPOJO>();
        
        try (Connection conn = connProvider.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, vuelo.getNombreCiudadSalida());
            //pstmt.setString(2, vuelo.getNombreCiudadSalida());
            pstmt.setFloat(2, vuelo.getPrecio());
            pstmt.setString(3, vuelo.getHoraSalida());
            pstmt.setString(4, vuelo.getHoraLlegada());
            //pstmt.setString(5, vuelo.getNombreAerolinea());
            //pstmt.executeUpdate();
            ResultSet rs;
            //rs = pstmt.executeQuery(query);
            rs = pstmt.executeQuery();
            
            
            while (rs.next()) {
                VueloPOJO vueloFiltrado = new VueloPOJO();
                vueloFiltrado.setIdVueloGenerico(rs.getInt("idVueloGenerico"));
                vueloFiltrado.setnVuelo(rs.getInt("nVuelo"));
                vueloFiltrado.setHoraSalida(rs.getString("horaSalida"));
                vueloFiltrado.setHoraLlegada(rs.getString("horaLlegada"));
                vueloFiltrado.setPrecio(rs.getFloat("precio"));
                vueloFiltrado.setCapacidad(rs.getInt("capacidad"));
                vueloFiltrado.setIdAerolínea(rs.getInt("idAerolínea"));
                vueloFiltrado.setNombreAerolinea(rs.getString("nombreAerolinea"));
                vueloFiltrado.setCodigoAerolinea(rs.getString("codigoAerolinea"));
                vueloFiltrado.setIdAeropuerto(rs.getInt("idAeropuerto"));
                vueloFiltrado.setNombreAeropuerto(rs.getString("nombreAeropuerto"));
                vueloFiltrado.setCodigoAeropuerto(rs.getString("codigoAeropuerto"));
                vueloFiltrado.setCategoria(rs.getInt("categoria"));
                vueloFiltrado.setIdCiudad(rs.getInt("idCiudad"));
                vueloFiltrado.setNombreCiudad(rs.getString("nombreCiudad"));
                vueloFiltrado.setPais(rs.getString("pais"));
                vueloFiltrado.setIdVuelo(rs.getInt("idVuelo"));
                vueloFiltrado.setPlazasLibres(rs.getInt("fecha"));
                vueloFiltrado.setFecha(rs.getString("plazasLibres"));

                listaVuelos.add(vueloFiltrado);
            }
            
            connProvider.closeConnection(conn);
        } catch (SQLException ex) {
            Logger.getLogger(MysqlVueloDao.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listaVuelos;
    }

    @Override
    public List<VueloPOJO> selectAll() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

        final String query = "select idVueloGenerico,nVuelo,horaSalida,horaLlegada,precio,capacidad,idAerolínea,nombreAerolinea, "
                + "codigoAerolinea,idAeropuerto,nombreAeropuerto,codigoAeropuerto,categoria,idCiudad,nombreCiudad,pais, idVuelo, fecha, plazasLibres from vista_vuelos;";
        List<VueloPOJO> listaVuelos = new ArrayList<VueloPOJO>();

        try (Connection conn = connProvider.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            ResultSet rs = pstmt.executeQuery(query);

            while (rs.next()) {
                VueloPOJO vuelo = new VueloPOJO();
                vuelo.setIdVueloGenerico(rs.getInt("idVueloGenerico"));
                vuelo.setnVuelo(rs.getInt("nVuelo"));
                vuelo.setHoraSalida(rs.getString("horaSalida"));
                vuelo.setHoraLlegada(rs.getString("horaLlegada"));
                vuelo.setPrecio(rs.getFloat("precio"));
                vuelo.setCapacidad(rs.getInt("capacidad"));
                vuelo.setIdAerolínea(rs.getInt("idAerolínea"));
                vuelo.setNombreAerolinea(rs.getString("nombreAerolinea"));
                vuelo.setCodigoAerolinea(rs.getString("codigoAerolinea"));
                vuelo.setIdAeropuerto(rs.getInt("idAeropuerto"));
                vuelo.setNombreAeropuerto(rs.getString("nombreAeropuerto"));
                vuelo.setCodigoAeropuerto(rs.getString("codigoAeropuerto"));
                vuelo.setCategoria(rs.getInt("categoria"));
                vuelo.setIdCiudad(rs.getInt("idCiudad"));
                vuelo.setNombreCiudad(rs.getString("nombreCiudad"));
                vuelo.setPais(rs.getString("pais"));
                vuelo.setIdVuelo(rs.getInt("idVuelo"));
                vuelo.setPlazasLibres(rs.getInt("plazasLibres"));
                vuelo.setFecha(rs.getString("fecha"));

                listaVuelos.add(vuelo);
            }
            connProvider.closeConnection(conn);
        } catch (SQLException ex) {
            Logger.getLogger(MysqlVueloDao.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listaVuelos;
    }

    @Override
    public void insert(ReservaPOJO reserva) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        final String query = "INSERT INTO reservas (nReservas,nombre,apellidos,telefono,tarjeta,idVuelo,importe) VALUES (?,?,?,?,?,?,?);";

        try (Connection conn = connProvider.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, reserva.getnReservas());
            pstmt.setString(2, reserva.getNombre());
            pstmt.setString(3, reserva.getApellidos());
            pstmt.setString(4, reserva.getTelefono());
            pstmt.setString(5, reserva.getTarjeta());
            pstmt.setInt(6, reserva.getIdVuelo());
            pstmt.setInt(7, reserva.getImporte());
            pstmt.executeUpdate();
            connProvider.closeConnection(conn);
        } catch (SQLException ex) {
            Logger.getLogger(MysqlVueloDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
        
        
        
        
    }

    @Override
    public Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void closeConnection(Connection conn) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
