package es.cifpcm.vuelos.Dao;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import es.cifpcm.vuelos.conection.ConnectionProvider;
import es.cifpcm.vuelos.conection.DatabaseConfig;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author 2dawb
 */
public class MySqlDaoFactory implements ConnectionProvider {

    private static MySqlDaoFactory instance;
    private final DatabaseConfig dbCfg = new DatabaseConfig();
    private InitialContext ctx;
    private DataSource ds;

    @Override
    public java.sql.Connection getConnection() {

        try {
            this.ctx = new InitialContext();
            this.ds = (DataSource) ctx.lookup("jdbc/reservas");
        } catch (NamingException ex) {
            java.util.logging.Logger.getLogger(MySqlDaoFactory.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            return ds.getConnection(dbCfg.getDatabaseUser(), dbCfg.getDatabasePassword());
        } catch (SQLException ex) {
            return null;
        }
    }

    private MySqlDaoFactory() {

        try {

            ResourceBundle rb = ResourceBundle.getBundle("database");
            dbCfg.setDriverClassName(rb.getString("database.driver"));
            dbCfg.setDatabaseUrl(rb.getString("database.url"));
            dbCfg.setDatabaseUser(rb.getString("database.user"));
            dbCfg.setDatabasePassword(rb.getString("database.password"));

            Class.forName(dbCfg.getDriverClassName());
        } catch (ClassNotFoundException ex) {

        }

    }

    @Override
    public void closeConnection(java.sql.Connection conn) {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(MySqlDaoFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static synchronized MySqlDaoFactory getInstance() {
        if (instance == null) {
            instance = new MySqlDaoFactory();
        }
        return instance;
    }
   
    public VueloDao getVueloDao() {
        VueloDao vuelo = new MysqlVueloDao(this);

        return vuelo;
    }


}
