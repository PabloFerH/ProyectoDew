/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cifpcm.vuelos.Dao;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Pablo1
 */
@XmlRootElement
public class VueloPOJO implements Serializable{
    
    private Integer idVueloGenerico;
    private Integer nVuelo;
    private String horaSalida;
    private String horaLlegada;
    private Float precio;
    private Integer capacidad;
    private Integer idAerolínea;
    private String  nombreAerolinea;
    private String codigoAerolinea;
    private Integer idAeropuerto;
    private String nombreAeropuerto;
    private String nombreAeropuertoSalida;
    private String nombreAeropuertoLlegada;
    private String codigoAeropuerto;
    private Integer categoria;
    private Integer idCiudad;
    private String nombreCiudad;
    private String nombreCiudadSalida;
    private String nombreCiudadLlegada;
    private String pais;
    private Integer idVuelo;
    private Integer plazasLibres;
    private String fecha;
    
    public VueloPOJO() {
    }

    public VueloPOJO(String horaSalida, String horaLlegada, Float precio, String nombreAerolinea, String nombreCiudadSalida, String nombreCiudadLlegada) {
        this.horaSalida = horaSalida;
        this.horaLlegada = horaLlegada;
        this.precio = precio;
        this.nombreAerolinea = nombreAerolinea;
        this.nombreCiudadSalida = nombreCiudadSalida;
        this.nombreCiudadLlegada = nombreCiudadLlegada;
    }

    public Integer getIdVuelo() {
        return idVuelo;
    }

    public void setIdVuelo(Integer idVuelo) {
        this.idVuelo = idVuelo;
    }

    public Integer getPlazasLibres() {
        return plazasLibres;
    }

    public void setPlazasLibres(Integer plazasLibres) {
        this.plazasLibres = plazasLibres;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getNombreCiudadSalida() {
        return nombreCiudadSalida;
    }

    public void setNombreCiudadSalida(String nombreCiudadSalida) {
        this.nombreCiudadSalida = nombreCiudadSalida;
    }

    public String getNombreCiudadLlegada() {
        return nombreCiudadLlegada;
    }

    public void setNombreCiudadLlegada(String nombreCiudadLlegada) {
        this.nombreCiudadLlegada = nombreCiudadLlegada;
    }

    public Integer getIdVueloGenerico() {
        return idVueloGenerico;
    }

    public void setIdVueloGenerico(Integer idVueloGenerico) {
        this.idVueloGenerico = idVueloGenerico;
    }

    public Integer getnVuelo() {
        return nVuelo;
    }

    public void setnVuelo(Integer nVuelo) {
        this.nVuelo = nVuelo;
    }

    public String getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(String horaSalida) {
        this.horaSalida = horaSalida;
    }

    public String getHoraLlegada() {
        return horaLlegada;
    }

    public void setHoraLlegada(String horaLlegada) {
        this.horaLlegada = horaLlegada;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    public Integer getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(Integer capacidad) {
        this.capacidad = capacidad;
    }

    public Integer getIdAerolínea() {
        return idAerolínea;
    }

    public void setIdAerolínea(Integer idAerolínea) {
        this.idAerolínea = idAerolínea;
    }

    public String getNombreAerolinea() {
        return nombreAerolinea;
    }

    public void setNombreAerolinea(String nombreAerolinea) {
        this.nombreAerolinea = nombreAerolinea;
    }

    public String getCodigoAerolinea() {
        return codigoAerolinea;
    }

    public void setCodigoAerolinea(String codigoAerolinea) {
        this.codigoAerolinea = codigoAerolinea;
    }

    public Integer getIdAeropuerto() {
        return idAeropuerto;
    }

    public void setIdAeropuerto(Integer idAeropuerto) {
        this.idAeropuerto = idAeropuerto;
    }

    public String getNombreAeropuerto() {
        return nombreAeropuerto;
    }

    public void setNombreAeropuerto(String nombreAeropuerto) {
        this.nombreAeropuerto = nombreAeropuerto;
    }

    public String getNombreAeropuertoSalida() {
        return nombreAeropuertoSalida;
    }

    public void setNombreAeropuertoSalida(String nombreAeropuertoSalida) {
        this.nombreAeropuertoSalida = nombreAeropuertoSalida;
    }

    public String getNombreAeropuertoLlegada() {
        return nombreAeropuertoLlegada;
    }

    public void setNombreAeropuertoLlegada(String nombreAeropuertoLlegada) {
        this.nombreAeropuertoLlegada = nombreAeropuertoLlegada;
    }

    public String getCodigoAeropuerto() {
        return codigoAeropuerto;
    }

    public void setCodigoAeropuerto(String codigoAeropuerto) {
        this.codigoAeropuerto = codigoAeropuerto;
    }

    public Integer getCategoria() {
        return categoria;
    }

    public void setCategoria(Integer categoria) {
        this.categoria = categoria;
    }

    public Integer getIdCiudad() {
        return idCiudad;
    }

    public void setIdCiudad(Integer idCiudad) {
        this.idCiudad = idCiudad;
    }

    public String getNombreCiudad() {
        return nombreCiudad;
    }

    public void setNombreCiudad(String nombreCiudad) {
        this.nombreCiudad = nombreCiudad;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }
    
    
  
    
}
