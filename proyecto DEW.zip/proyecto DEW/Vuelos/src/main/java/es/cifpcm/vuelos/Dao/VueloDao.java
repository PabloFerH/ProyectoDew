/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cifpcm.vuelos.Dao;

import java.util.List;

/**
 *
 * @author Pablo1
 */
public interface VueloDao {
    List<VueloPOJO> select(VueloPOJO vuelo);
    List<VueloPOJO> selectAll();
    void insert(ReservaPOJO reserva);
}
