$(document).ready(function(){
	$(".idiomas").on("click", function(){
		var click = this.id;
		$().cargarDatos(click);
	});

});

$.fn.cargarDatos = function(click){
	$.getJSON('json/datos.json', function(data) {
		$().cambiarLanguaje(data, click);
	});
}

$.fn.cambiarLanguaje = function(data, elemento){
	var valores = Object.keys(data.datos[elemento]); 
	for(var i = 0; i < Object.keys(data.datos[elemento]).length; i++){
		var texto = valores[i];
		
		//fix that shit
		/*
		$("#"+valores[i]).fadeOut(500, function() {
			
			$(this).text(data.datos[elemento][texto]).fadeIn(500);
		});*/
	
	$("#"+valores[i]).fadeOut(500);
	$("#"+valores[i]).text(data.datos[elemento][texto]).fadeIn(500);



	/*
	$("#"+valores[i]).promise().done(function(){
			$("#"+valores[i]).text(data.datos[elemento][texto]).fadeIn(500);
	});*/
	
	
	}
	$().flecha();
}

$.fn.flecha = function(){
	var flecha = $("<span class='glyphicon glyphicon-chevron-down' aria-hidden='true' id='iconoIdioma'></span>");
	$("#menu1").append(flecha);
}
/*
$.fn.transition = function(){
	$("#"+valores[i]).promise().done(function(){
			$("#"+valores[i]).text(data.datos[elemento][texto]).fadeIn(500);
	});
}*/